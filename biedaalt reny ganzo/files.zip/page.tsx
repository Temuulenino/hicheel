'use client'

import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import {
  MapPin, ArrowRight, Shield, Users, Clock, Star,
  ChevronDown, Phone, CheckCircle, Car, Navigation
} from 'lucide-react'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'

const cities = [
  'Улаанбаатар', 'Дархан', 'Эрдэнэт', 'Чойбалсан', 'Мөрөн',
  'Баянхонгор', 'Даланзадгад', 'Өлгий', 'Улаангом', 'Арвайхээр',
]

export default function HomePage() {
  const router = useRouter()
  const [origin, setOrigin] = useState('')
  const [destination, setDestination] = useState('')
  const [date, setDate] = useState('')

  const handleSearch = () => {
    const params = new URLSearchParams()
    if (origin) params.set('origin', origin)
    if (destination) params.set('destination', destination)
    if (date) params.set('date', date)
    router.push(`/rides?${params.toString()}`)
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <Navbar />

      {/* Hero */}
      <section className="relative bg-dark-200 overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-5">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `radial-gradient(circle at 25px 25px, #3B82F6 1px, transparent 0)`,
              backgroundSize: '50px 50px',
            }}
          />
        </div>
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-primary-900/20 to-transparent" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-primary-500/10 border border-primary-500/20 rounded-full px-4 py-1.5 mb-6">
              <span className="w-2 h-2 rounded-full bg-primary-400 animate-pulse-soft" />
              <span className="text-primary-300 text-sm font-medium">Монголын #1 аяллын платформ</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              Аймаг хотруу{' '}
              <span className="text-primary-400">найдвартай</span>{' '}
              аяллаарай
            </h1>
            <p className="text-lg text-neutral-400 mb-10 leading-relaxed">
              Facebook группт пост тавиад хүлээх хэрэггүй. AimagRide дээр жолооч хайж, суудал захиалж, аюулгүй аяллаарай.
            </p>

            {/* Search Box */}
            <div className="bg-white rounded-2xl p-2 shadow-modal">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                  <select
                    value={origin}
                    onChange={(e) => setOrigin(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-neutral-50 border-0 text-neutral-700 focus:outline-none focus:ring-2 focus:ring-primary-500 appearance-none cursor-pointer"
                  >
                    <option value="">Хаанаас?</option>
                    {cities.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div className="relative">
                  <Navigation className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                  <select
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-neutral-50 border-0 text-neutral-700 focus:outline-none focus:ring-2 focus:ring-primary-500 appearance-none cursor-pointer"
                  >
                    <option value="">Хаашаа?</option>
                    {cities.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div className="relative">
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-neutral-50 border-0 text-neutral-700 focus:outline-none focus:ring-2 focus:ring-primary-500 cursor-pointer"
                  />
                </div>
              </div>
              <div className="mt-2">
                <button
                  onClick={handleSearch}
                  className="w-full bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 rounded-xl transition-all duration-150 active:scale-[0.99] flex items-center justify-center gap-2"
                >
                  Аялал хайх
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-white border-b border-neutral-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: 'Бүртгэлтэй жолооч', value: '2,400+', icon: Car },
              { label: 'Амжилттай аялал', value: '18,000+', icon: CheckCircle },
              { label: 'Идэвхтэй хэрэглэгч', value: '35,000+', icon: Users },
              { label: 'Хамарсан хот, аймаг', value: '21', icon: MapPin },
            ].map((stat) => (
              <div key={stat.label} className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary-50 rounded-xl flex items-center justify-center flex-shrink-0">
                  <stat.icon className="w-5 h-5 text-primary-600" />
                </div>
                <div>
                  <div className="text-xl font-bold text-neutral-900">{stat.value}</div>
                  <div className="text-xs text-neutral-500">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold text-neutral-900 mb-3">Хэрхэн ажилладаг вэ?</h2>
            <p className="text-neutral-500 max-w-xl mx-auto">Гурван хялбар алхамаар аялалаа зохицуул</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Аялал хайх',
                desc: 'Хаанаас хаашаа явахаа, огноогоо оруулаад аялал хайж олно.',
                color: 'bg-primary-50 text-primary-600',
              },
              {
                step: '02',
                title: 'Суудал захиалах',
                desc: 'Таньд тохирсон жолоочийн мэдээллийг харж, суудал захиална.',
                color: 'bg-accent-50 text-accent-600',
              },
              {
                step: '03',
                title: 'Аялаарай',
                desc: 'Жолоочтойгоо уулзах цэгийг тохиролцоод, тааламжтай аялаарай.',
                color: 'bg-green-50 text-green-600',
              },
            ].map((item) => (
              <div key={item.step} className="card p-7 relative">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-lg font-bold mb-5 ${item.color}`}>
                  {item.step}
                </div>
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">{item.title}</h3>
                <p className="text-neutral-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white" id="features">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-primary-50 rounded-full px-4 py-1.5 mb-5">
                <span className="text-primary-600 text-sm font-medium">Яагаад AimagRide?</span>
              </div>
              <h2 className="text-3xl font-bold text-neutral-900 mb-5 leading-tight">
                Facebook группоос илүү найдвартай, хурдан, аюулгүй
              </h2>
              <p className="text-neutral-500 mb-8 leading-relaxed">
                Одоо хүмүүс Facebook-т пост тавиад хүлээдэг. Энэ нь удаан, аюулгүй биш. AimagRide дээр бүх жолооч баталгаажсан, бүх аялал нийтэд харагдана.
              </p>
              <div className="space-y-4">
                {[
                  { icon: Shield, title: 'Баталгаажсан жолооч', desc: 'Бүх жолооч иргэний үнэмлэхээр баталгаажсан' },
                  { icon: Clock, title: 'Шуурхай захиалга', desc: 'Хэдэн минутын дотор суудал захиалах боломжтой' },
                  { icon: Phone, title: 'Шууд холбоо', desc: 'Жолоочийн утасны дугааруудыг шууд харж холбогдоно' },
                  { icon: Star, title: 'Үнэлгээний систем', desc: 'Жолоочийн туршлага, үнэлгээг урьдчилан харна' },
                ].map((f) => (
                  <div key={f.title} className="flex items-start gap-4">
                    <div className="w-9 h-9 bg-primary-50 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5">
                      <f.icon className="w-4 h-4 text-primary-600" />
                    </div>
                    <div>
                      <div className="font-medium text-neutral-800 text-sm">{f.title}</div>
                      <div className="text-neutral-500 text-sm">{f.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              {/* Mock ride cards */}
              {[
                { from: 'Улаанбаатар', to: 'Эрдэнэт', time: '07:00', seats: 3, price: '45,000₮', driver: 'Б. Мөнхбаатар' },
                { from: 'Улаанбаатар', to: 'Дархан', time: '08:30', seats: 2, price: '35,000₮', driver: 'Д. Болдбаатар' },
                { from: 'Эрдэнэт', to: 'Мөрөн', time: '09:00', seats: 4, price: '55,000₮', driver: 'Г. Нарантуяа' },
              ].map((ride, i) => (
                <div key={i} className="card p-5 flex items-center justify-between hover:shadow-card-hover transition-all duration-200 cursor-pointer">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-primary-100 flex items-center justify-center">
                      <Car className="w-5 h-5 text-primary-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-neutral-800 text-sm">
                        {ride.from} → {ride.to}
                      </div>
                      <div className="text-xs text-neutral-500">{ride.driver} • {ride.time}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-neutral-900 text-sm">{ride.price}</div>
                    <div className="text-xs text-neutral-400">{ride.seats} суудал</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-dark-200">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Өнөөдөр эхлэх үү?</h2>
          <p className="text-neutral-400 mb-8 text-lg">Бүртгүүлж, анхны аялалаа захиал эсвэл аялал нэмж, орлогоо нэм.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/auth/signup"
              className="bg-primary-600 hover:bg-primary-700 text-white font-semibold px-8 py-3 rounded-xl transition-all inline-flex items-center justify-center gap-2"
            >
              Зорчигчоор бүртгүүлэх
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/auth/signup"
              className="bg-white/10 hover:bg-white/15 text-white font-semibold px-8 py-3 rounded-xl transition-all inline-flex items-center justify-center gap-2 border border-white/10"
            >
              Жолоочоор бүртгүүлэх
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
