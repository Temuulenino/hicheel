# AimagRide 🚗

**Монголын хотхоорондын найдвартай аяллын платформ**

Facebook группын "замд дайрч авна" хэв маягийг орлох, жолооч болон зорчигчдыг нэг найдвартай, баталгаажсан платформд холбоно.

---

## Технологийн стек

| Давхарга | Технологи |
|----------|-----------|
| Frontend | Next.js 14, React, TypeScript, TailwindCSS |
| Backend  | Django 4.2, Django REST Framework |
| Database | PostgreSQL |
| Auth     | JWT (SimpleJWT) |
| Deploy   | Gunicorn + Nginx |

---

## Эхлүүлэх заавар

### Шаардлага
- Node.js 18+
- Python 3.11+
- PostgreSQL 15+

---

## 1. PostgreSQL Database үүсгэх

```sql
CREATE DATABASE aimagride_db;
CREATE USER aimagride_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE aimagride_db TO aimagride_user;
```

---

## 2. Backend тохируулах

```bash
cd AimagRide/backend

# Virtual environment үүсгэх
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate

# Packages суулгах
pip install -r requirements.txt

# Environment variables тохируулах
copy .env.example .env
# .env файлыг нээж DB нууц үг болон бусад утгыг оруулна уу

# Database migration
python manage.py makemigrations users
python manage.py makemigrations rides
python manage.py makemigrations bookings
python manage.py migrate

# Superuser (Admin) үүсгэх
python manage.py createsuperuser

# Development server ажиллуулах
python manage.py runserver
```

Backend нь http://localhost:8000 дээр ажиллана.

---

## 3. Frontend тохируулах

```bash
cd AimagRide/frontend

# Packages суулгах
npm install

# Environment variables
copy .env.example .env.local
# NEXT_PUBLIC_API_URL=http://localhost:8000/api гэж тохируулагдсан байна

# Development server ажиллуулах
npm run dev
```

Frontend нь http://localhost:3000 дээр ажиллана.

---

## 4. Admin Dashboard руу нэвтрэх

1. http://localhost:3000/admin дээр орно уу
2. `python manage.py createsuperuser` аар үүсгэсэн нэвтрэх нэр, нууц үгийг ашиглана уу
3. Django admin: http://localhost:8000/django-admin/

---

## API Endpoints

### Auth
| Method | URL | Тайлбар |
|--------|-----|---------|
| POST | `/api/auth/register/` | Бүртгүүлэх |
| POST | `/api/auth/login/` | Нэвтрэх |
| POST | `/api/auth/logout/` | Гарах |
| GET  | `/api/auth/me/` | Өөрийн мэдээлэл |
| POST | `/api/auth/verify-email/` | Имэйл баталгаажуулах |
| POST | `/api/auth/verify-phone/` | Утас баталгаажуулах |
| POST | `/api/auth/token/refresh/` | Token шинэчлэх |

### Rides
| Method | URL | Тайлбар |
|--------|-----|---------|
| GET  | `/api/rides/` | Аялалуудын жагсаалт |
| POST | `/api/rides/` | Аялал нэмэх (жолооч) |
| GET  | `/api/rides/{id}/` | Аялалын дэлгэрэнгүй |
| PATCH | `/api/rides/{id}/` | Аялал засах |
| DELETE | `/api/rides/{id}/` | Аялал устгах |
| GET  | `/api/rides/search/` | Аялал хайх |
| GET  | `/api/rides/my-rides/` | Миний аялалууд |

### Bookings
| Method | URL | Тайлбар |
|--------|-----|---------|
| GET  | `/api/bookings/` | Захиалгуудын жагсаалт |
| POST | `/api/bookings/` | Захиалга хийх |
| GET  | `/api/bookings/my-bookings/` | Миний захиалгууд |
| PATCH | `/api/bookings/{id}/cancel/` | Захиалга цуцлах |

### Locations
| Method | URL | Тайлбар |
|--------|-----|---------|
| GET  | `/api/locations/cities/` | Хотуудын жагсаалт |
| GET  | `/api/locations/meeting-points/` | Уулзах цэгүүд |

### Verification
| Method | URL | Тайлбар |
|--------|-----|---------|
| POST | `/api/verification/submit/` | Баталгаажуулалт илгээх |
| GET  | `/api/verification/status/` | Баталгаажуулалтын төлөв |

### Admin (Staff only)
| Method | URL | Тайлбар |
|--------|-----|---------|
| GET  | `/api/admin/stats/` | Статистик |
| GET  | `/api/admin/users/` | Хэрэглэгчид |
| PATCH | `/api/admin/users/{id}/suspend/` | Хэрэглэгч хязгаарлах |
| GET  | `/api/admin/verifications/pending/` | Хүлээгдэх баталгаа |
| PATCH | `/api/admin/verifications/{id}/approve/` | Батлах |
| PATCH | `/api/admin/verifications/{id}/reject/` | Татгалзах |
| GET/POST | `/api/admin/meeting-points/` | Байршил удирдах |

---

## Хавтасны бүтэц

```
AimagRide/
├── frontend/                    # Next.js App
│   ├── app/
│   │   ├── page.tsx             # Нүүр хуудас
│   │   ├── rides/               # Аялал хайх & дэлгэрэнгүй
│   │   ├── post-ride/           # Аялал нэмэх
│   │   ├── auth/                # Нэвтрэх, бүртгүүлэх
│   │   ├── profile/             # Профайл
│   │   ├── my-rides/            # Миний аялалууд
│   │   ├── my-bookings/         # Миний захиалгууд
│   │   ├── settings/            # Тохиргоо
│   │   ├── admin/               # Админ самбар
│   │   ├── support/             # Тусламж
│   │   └── contact/             # Холбоо барих
│   ├── components/
│   │   ├── layout/              # Navbar, Footer
│   │   └── rides/               # RideCard
│   ├── hooks/useAuth.tsx        # Auth context
│   ├── lib/api.ts               # Axios API client
│   ├── lib/utils.ts             # Utility functions
│   └── types/index.ts           # TypeScript types
│
└── backend/                     # Django Project
    ├── aimagride/               # Django settings & urls
    ├── apps/
    │   ├── users/               # User model, auth, verification
    │   ├── rides/               # Ride, City, MeetingPoint models
    │   ├── bookings/            # Booking, Payment models
    │   └── admin_panel/         # Admin API views
    ├── requirements.txt
    └── .env.example
```

---

## Аюулгүй байдал

- JWT токен баталгаажуулалт
- Django CSRF хамгаалалт
- SQL Injection-оос ORM-р хамгаалагдсан
- Нууц үг bcrypt/PBKDF2-р хаш хийгдсэн
- Rate limiting (100 req/hour anon, 1000/hour user)
- CORS тохиргоо
- Production дахь HTTPS, HSTS

---

## Production Deploy

### Backend (Ubuntu + Nginx + Gunicorn)

```bash
# settings.py дахь
DEBUG=False
ALLOWED_HOSTS=yourdomain.com

# Gunicorn
gunicorn aimagride.wsgi:application --workers 3 --bind 0.0.0.0:8000

# Static files
python manage.py collectstatic
```

### Frontend (Vercel эсвэл VPS)

```bash
npm run build
npm start
# эсвэл Vercel дээр deploy хийх
```

---

## Хөгжүүлэлтийн дараагийн алхамууд

- [ ] Twilio SMS OTP интеграци
- [ ] Онлайн төлбөрийн систем (QPay, SocialPay)
- [ ] Push notification
- [ ] Жолоочийн үнэлгээний систем
- [ ] Газрын зураг (Google Maps)
- [ ] Мобайл апп (React Native)

---

**AimagRide** — Монголчуудын аяллыг ухаалгаар зохицуулна. 🇲🇳
